https://www.youtube.com/watch?v=ZpszSj3ziQk
https://www.youtube.com/watch?v=TKbqzoeYKmo&list=PL8p2I9GklV456iofeMKReMTvWLr7Ki9At&index=39


https://www.youtube.com/@thesheryianscodingschool/videos